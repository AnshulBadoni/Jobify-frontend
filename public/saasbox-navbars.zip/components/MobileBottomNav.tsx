// This component has been merged into components/Navbar.tsx
export const MobileBottomNav = () => null;