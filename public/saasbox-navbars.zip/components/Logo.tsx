import React from 'react';

interface LogoProps {
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ showText = true }) => {
  return (
    <div className="flex items-center gap-2.5 cursor-pointer">
      <div className="w-8 h-8 relative flex items-center justify-center">
         {/* Custom Abstract Logo */}
         <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 26L14 10L24 26H4Z" fill="url(#paint0_linear)" />
            <path d="M14 26L22 14L30 26H14Z" fill="url(#paint1_linear)" />
            <defs>
              <linearGradient id="paint0_linear" x1="14" y1="10" x2="14" y2="26" gradientUnits="userSpaceOnUse">
                <stop stopColor="#2F54EB" />
                <stop offset="1" stopColor="#597EF7" />
              </linearGradient>
              <linearGradient id="paint1_linear" x1="22" y1="14" x2="22" y2="26" gradientUnits="userSpaceOnUse">
                <stop stopColor="#597EF7" />
                <stop offset="1" stopColor="#85A5FF" />
              </linearGradient>
            </defs>
         </svg>
      </div>
      {showText && (
        <span className="text-xl font-bold text-slate-900 dark:text-white tracking-tight transition-colors">JobSync</span>
      )}
    </div>
  );
};