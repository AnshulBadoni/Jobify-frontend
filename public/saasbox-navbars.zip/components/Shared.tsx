import React, { useState, useRef, useEffect } from 'react';
import { Search, Settings, Bell, X, MapPin, FileText, Share2, Zap, Moon, Sun, Briefcase } from 'lucide-react';

interface NavActionIconsProps {
  isSearchOpen?: boolean;
  onToggleSearch?: () => void;
}

export const NavActionIcons: React.FC<NavActionIconsProps> = ({ isSearchOpen, onToggleSearch }) => {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  return (
    <div className="flex items-center gap-2 md:gap-4 text-slate-500 dark:text-slate-400">
      <button 
        onClick={onToggleSearch}
        className={`hover:text-slate-900 dark:hover:text-white transition-colors p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 ${isSearchOpen ? 'text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800' : ''}`}
        aria-label={isSearchOpen ? "Close Search" : "Open Search"}
      >
        {isSearchOpen ? <X size={20} strokeWidth={2.5} /> : <Search size={20} strokeWidth={2.5} />}
      </button>
      
      <button 
        onClick={() => setIsDark(!isDark)}
        className="hover:text-slate-900 dark:hover:text-white transition-colors p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
        aria-label="Toggle Dark Mode"
      >
        {isDark ? <Sun size={20} strokeWidth={2} /> : <Moon size={20} strokeWidth={2} />}
      </button>

      <button className="hover:text-slate-900 dark:hover:text-white transition-colors p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
        <Settings size={20} strokeWidth={2} />
      </button>
      <button className="hover:text-slate-900 dark:hover:text-white transition-colors p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
        <Bell size={20} strokeWidth={2} />
      </button>
    </div>
  );
};

export const UserProfile: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isOpen &&
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        !triggerRef.current?.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  return (
    <div className="relative">
      {/* Trigger: Profile Image */}
      <div 
        ref={triggerRef}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-4 pl-4 border-l border-gray-200 dark:border-slate-800 h-8 cursor-pointer group select-none"
      >
        <div className="hidden md:block bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-full text-xs font-semibold tracking-wide whitespace-nowrap group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/50 transition-colors">
          Open to Work
        </div>
        <img 
          src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
          alt="User Avatar" 
          className={`w-9 h-9 rounded-full object-cover border-2 border-white dark:border-slate-900 shadow-sm transition-all ${isOpen ? 'ring-2 ring-brand-blue' : 'ring-1 ring-gray-100 dark:ring-slate-700 group-hover:ring-gray-200 dark:group-hover:ring-slate-600'}`}
        />
      </div>

      {/* Dropdown Card */}
      {isOpen && (
        <div 
          ref={dropdownRef}
          className="absolute right-0 top-full mt-6 w-[360px] bg-white dark:bg-slate-900 rounded-[32px] shadow-2xl border border-slate-100 dark:border-slate-800 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-300 origin-top-right"
        >
          {/* Card Content */}
          <div className="p-7 pb-8">
            {/* Header: Status & Location */}
            <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400 mb-6">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Actively looking</span>
              </div>
              <div className="flex items-center gap-1.5 opacity-80">
                <MapPin size={14} />
                <span>San Francisco, CA</span>
              </div>
            </div>

            {/* Profile Info */}
            <div className="flex items-center gap-5 mb-8">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                alt="Profile" 
                className="w-[72px] h-[72px] rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-lg"
              />
              <div>
                <h3 className="text-[22px] font-bold text-slate-900 dark:text-white leading-tight mb-0.5">Alex Morgan</h3>
                <p className="text-slate-400 dark:text-slate-500 text-sm font-medium">Product Designer</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3.5">
              <button className="flex items-center justify-center gap-2 bg-brand-blue hover:bg-blue-600 text-white py-3.5 rounded-2xl font-semibold text-sm transition-all active:scale-95 shadow-lg shadow-blue-500/25">
                <FileText size={18} strokeWidth={2.5} />
                Resume
              </button>
              <button className="flex items-center justify-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 py-3.5 rounded-2xl font-semibold text-sm transition-all active:scale-95">
                <Share2 size={18} strokeWidth={2.5} />
                Share
              </button>
            </div>
          </div>

          {/* Footer Bar */}
          <div className="bg-slate-50 dark:bg-slate-800/50 py-3.5 flex items-center justify-center gap-2 text-slate-500 dark:text-slate-400 text-xs font-semibold tracking-wide border-t border-slate-100 dark:border-slate-800">
            <Briefcase size={14} />
            <span>5 Applications Active</span>
          </div>
        </div>
      )}
    </div>
  );
};

interface NavLinkProps {
  label: string;
  active?: boolean;
  icon?: React.ReactNode;
  compact?: boolean;
}

export const NavLink: React.FC<NavLinkProps> = ({ label, active, icon, compact }) => {
  // Base classes for the link container
  const baseClasses = "flex items-center justify-center transition-all duration-500 ease-[cubic-bezier(0.33,1,0.68,1)] overflow-hidden whitespace-nowrap";
  
  // Styles for active vs inactive
  const activeClasses = active 
    ? "bg-brand-blue text-white shadow-md shadow-blue-500/20 hover:bg-blue-600 active:scale-95" 
    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800";

  // Padding adjustment based on compact state
  const paddingClasses = compact 
    ? "px-2.5 py-2.5 rounded-lg" // Square-like when icon only
    : "px-5 py-2.5 rounded-lg"; // Wide when text is shown

  return (
    <a href="#" className={`${baseClasses} ${activeClasses} ${paddingClasses} group`}>
      {/* Icon Wrapper */}
      <span className={`${compact ? '' : 'mr-0 lg:mr-2'} transition-all duration-300 flex items-center justify-center`}>
        {icon}
      </span>

      {/* Text Label */}
      <span 
        className={`
          font-semibold text-sm transition-all duration-500 ease-[cubic-bezier(0.33,1,0.68,1)]
          ${compact ? 'w-0 opacity-0 -ml-1' : 'w-auto opacity-100 max-w-[150px]'}
        `}
      >
        {label}
      </span>
    </a>
  );
};