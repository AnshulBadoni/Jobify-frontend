import React, { useEffect, useState, useRef } from 'react';
import { Search, X, ArrowUp, ArrowDown, CornerDownLeft, Briefcase, Building2, Users, CheckCircle2, MapPin, DollarSign, Clock, ChevronDown } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('Jobs');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      // Small delay to ensure focus works after animation
      setTimeout(() => inputRef.current?.focus(), 50);
    }

    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-24 px-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/20 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300 ring-1 ring-slate-900/5 dark:ring-slate-800">
        
        {/* Header Section */}
        <div className="flex flex-col border-b border-slate-100 dark:border-slate-800">
          {/* Search Input Row */}
          <div className="flex items-center px-4 py-4 gap-3">
            <Search className="text-brand-blue" size={20} strokeWidth={2.5} />
            <input 
              ref={inputRef}
              type="text"
              placeholder={activeTab === 'Jobs' ? "Search for 'Senior Frontend Developer'..." : activeTab === 'Companies' ? "Search companies..." : "Search candidates..."}
              className="flex-1 text-lg text-slate-900 dark:text-white placeholder:text-slate-400 bg-transparent border-none focus:outline-none focus:ring-0"
            />
            <button 
              onClick={onClose}
              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Navigation Hints Row */}
          <div className="flex items-center justify-between px-4 pb-3 text-xs font-medium text-slate-500 dark:text-slate-400 select-none">
            <div className="flex items-center gap-2">
              <span>Navigate</span>
              <div className="flex gap-1">
                <span className="flex items-center justify-center w-5 h-5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm"><ArrowUp size={12} /></span>
                <span className="flex items-center justify-center w-5 h-5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm"><ArrowDown size={12} /></span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span>Close</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm font-sans">esc</span>
            </div>
          </div>
        </div>

        {/* Filters / Tabs */}
        <div className="px-4 py-3 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          {['Jobs', 'Companies', 'People'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${
                activeTab === tab 
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border-slate-200 dark:border-slate-700 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {tab === 'Jobs' && <Briefcase size={14} />}
              {tab === 'Companies' && <Building2 size={14} />}
              {tab === 'People' && <Users size={14} />}
              {tab}
            </button>
          ))}
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium text-slate-500 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            Remote Only <ChevronDown size={14} />
          </button>
        </div>

        {/* Content List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-slate-700">
          
          {/* Jobs Section */}
          <div className={`${activeTab === 'Jobs' ? 'block' : 'hidden'}`}>
            <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              Recent Openings <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded text-[10px]">12</span>
            </div>
            <div className="space-y-1">
              <ResultItem 
                icon={<div className="w-8 h-8 rounded bg-blue-100 text-blue-600 flex items-center justify-center font-bold">G</div>}
                title="Senior Product Designer"
                subtitle="Google • Remote"
                rightContent={<StatusBadge status="New" color="green" />}
                meta="$180k - $220k"
                active
              />
              <ResultItem 
                icon={<div className="w-8 h-8 rounded bg-black text-white flex items-center justify-center font-bold">U</div>}
                title="Frontend Engineer (React)"
                subtitle="Uber • San Francisco, CA"
                meta="$160k - $190k"
              />
              <ResultItem 
                icon={<div className="w-8 h-8 rounded bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">S</div>}
                title="UX Researcher"
                subtitle="Spotify • New York, NY"
                meta="$140k - $170k"
              />
               <button className="w-full text-left px-3 py-2 text-sm text-brand-blue font-medium hover:underline">
                View all 124 jobs_
              </button>
            </div>
          </div>

          {/* Companies Section */}
           <div className={`${activeTab === 'Companies' ? 'block' : 'hidden'}`}>
            <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              Top Employers
            </div>
            <div className="space-y-1">
              <ResultItem 
                icon={<Building2 size={16} className="text-slate-500" />}
                title="Linear"
                subtitle="Productivity & Tools"
                rightContent={<span className="text-xs text-slate-400">12 Jobs</span>}
              />
              <ResultItem 
                icon={<Building2 size={16} className="text-slate-500" />}
                title="Vercel"
                subtitle="Cloud Infrastructure"
                rightContent={<span className="text-xs text-slate-400">8 Jobs</span>}
              />
            </div>
          </div>

           {/* People Section */}
           <div className={`${activeTab === 'People' ? 'block' : 'hidden'}`}>
             <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              Recruiters & Peers
            </div>
             <div className="space-y-1">
              <ResultItem 
                icon={<img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=32&h=32" className="w-8 h-8 rounded-full" alt="" />}
                title="Sarah Jenkins"
                subtitle="Technical Recruiter at Meta"
              />
              <ResultItem 
                icon={<img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=32&h=32" className="w-8 h-8 rounded-full" alt="" />}
                title="David Chen"
                subtitle="Engineering Manager at Airbnb"
              />
            </div>
           </div>

        </div>
      </div>
    </div>
  );
};

const ResultItem = ({ icon, title, subtitle, rightContent, meta, active }: any) => (
  <div className={`group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors ${active ? 'bg-slate-100 dark:bg-slate-800/60' : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'}`}>
    <div className="flex items-center gap-3">
      {typeof icon === 'string' ? <img src={icon} className="w-8 h-8 rounded-full" /> : icon}
      <div>
        <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-slate-200">{title}</span>
            {rightContent}
        </div>
        {subtitle && <div className="text-sm text-slate-500 dark:text-slate-400">{subtitle}</div>}
      </div>
    </div>
    <div className="flex items-center gap-3">
       {meta && (
        <div className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
            {meta}
        </div>
       )}
       {active && (
         <div className="hidden group-hover:flex items-center gap-1 text-xs font-medium text-slate-400">
           Select <CornerDownLeft size={12} />
         </div>
       )}
    </div>
  </div>
);

const StatusBadge = ({ status, color }: { status: string, color: 'orange' | 'pink' | 'green' }) => {
    const colors = {
        orange: 'bg-orange-50 text-orange-600 border-orange-100 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-900/30',
        pink: 'bg-pink-50 text-pink-600 border-pink-100 dark:bg-pink-900/20 dark:text-pink-400 dark:border-pink-900/30',
        green: 'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-900/30',
    };
    return (
        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${colors[color]}`}>
            {status}
        </span>
    );
};
