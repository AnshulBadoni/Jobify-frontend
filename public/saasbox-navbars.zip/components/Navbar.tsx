import React, { useState } from 'react';
import { Logo } from './Logo';
import { UserProfile, NavLink, NavActionIcons } from './Shared';
import { Briefcase, Building2, MessageSquare, Banknote, Users, Home, Search, Bell, Bookmark, User } from 'lucide-react';
import { SearchModal } from './SearchModal';

export const Navbar: React.FC = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <>
      <nav className="max-w-[1400px] mx-auto px-6 h-[88px] flex items-center justify-between bg-white dark:bg-slate-950 relative transition-colors duration-300">
        {/* Left: Logo */}
        <div className="flex-shrink-0 z-20 pr-6">
          <Logo />
        </div>

        {/* Center: Interactive Flex Container */}
        <div className="flex-1 flex items-center relative h-full">
          
          {/* Nav Links Container - Hidden on Mobile */}
          <div className="hidden md:flex items-center gap-1 lg:gap-2 mx-auto transition-all duration-500 ease-[cubic-bezier(0.33,1,0.68,1)] flex-shrink-0">
             <NavLink 
               label="Find Jobs" 
               icon={<Briefcase size={18} strokeWidth={2.5} />} 
               active 
               compact={isSearchOpen} 
             />
             <NavLink 
               label="Companies" 
               icon={<Building2 size={18} strokeWidth={2.5} />} 
               compact={isSearchOpen} 
             />
             <NavLink 
               label="Salaries" 
               icon={<Banknote size={18} strokeWidth={2.5} />} 
               compact={isSearchOpen} 
             />
             <NavLink 
               label="Messages" 
               icon={<MessageSquare size={18} strokeWidth={2.5} />} 
               compact={isSearchOpen} 
             />
             <NavLink 
               label="Community" 
               icon={<Users size={18} strokeWidth={2.5} />} 
               compact={isSearchOpen} 
             />
          </div>

          {/* Spacer Element - Expands to push nav links left */}
          <div 
            className={`
              transition-all duration-500 ease-[cubic-bezier(0.33,1,0.68,1)]
              ${isSearchOpen ? 'flex-1' : 'w-0'}
            `}
          />
        </div>

        {/* Right: Actions & Profile */}
        <div className="flex items-center gap-4 lg:gap-6 flex-shrink-0 z-20 pl-6">
          <NavActionIcons 
            isSearchOpen={isSearchOpen} 
            onToggleSearch={() => setIsSearchOpen(!isSearchOpen)} 
          />
          <div className="hidden md:block">
            <UserProfile />
          </div>
          {/* Mobile Profile Avatar only */}
          <div className="md:hidden">
            <img 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
              alt="User" 
              className="w-8 h-8 rounded-full border border-gray-200 dark:border-slate-700"
            />
          </div>
        </div>
      </nav>

      {/* The Search Modal Overlay */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      
      {/* Mobile Bottom Navigation */}
      <MobileBottomNav onSearchClick={() => setIsSearchOpen(true)} />
    </>
  );
};

// --- Sub-components ---

interface MobileBottomNavProps {
  onSearchClick: () => void;
}

const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ onSearchClick }) => {
  const [activeTab, setActiveTab] = React.useState('Jobs');

  const navItems = [
    { id: 'Home', icon: <Home size={24} strokeWidth={2.5} />, label: 'Home' },
    { id: 'Jobs', icon: <Briefcase size={24} strokeWidth={2.5} />, label: 'Jobs', action: onSearchClick },
    { id: 'Alerts', icon: <Bell size={24} strokeWidth={2.5} />, label: 'Alerts' },
    { id: 'Saved', icon: <Bookmark size={24} strokeWidth={2.5} />, label: 'Saved' },
    { id: 'Profile', icon: <User size={24} strokeWidth={2.5} />, label: 'Profile' },
  ];

  return (
    <div className="md:hidden fixed bottom-6 left-4 right-4 z-50">
      <div className="bg-white dark:bg-slate-900 rounded-[32px] shadow-2xl shadow-slate-200/50 dark:shadow-slate-950/50 border border-slate-100 dark:border-slate-800 h-[88px] px-6 flex items-center justify-between">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                if (item.action) item.action();
              }}
              className={`
                relative flex flex-col items-center justify-center gap-1.5 w-16 h-[72px] rounded-2xl transition-all duration-300
                ${isActive 
                  ? 'bg-brand-blue/10 text-brand-blue dark:bg-blue-900/20 dark:text-blue-400' 
                  : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'
                }
              `}
            >
              <div className={`transition-transform duration-300 ${isActive ? '-translate-y-0.5' : ''}`}>
                {item.icon}
              </div>
              <span className="text-[11px] font-semibold tracking-wide">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};