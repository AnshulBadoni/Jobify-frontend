// This variant has been deprecated. Please use components/Navbar.tsx
export const NavbarVariant3 = () => null;