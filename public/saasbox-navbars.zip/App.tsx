import React from 'react';
import { Navbar } from './components/Navbar';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 transition-colors duration-300">
      
      {/* Main Navbar */}
      <div className="w-full bg-white dark:bg-slate-900 shadow-sm border-b border-gray-100 dark:border-slate-800 transition-colors duration-300 sticky top-0 z-40">
        <Navbar />
      </div>

      {/* Placeholder Content */}
      <div className="max-w-[1400px] mx-auto px-6 py-12">
        <div className="w-full h-96 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-center text-slate-400">
          Job Platform Content
        </div>
      </div>

    </div>
  );
};

export default App;