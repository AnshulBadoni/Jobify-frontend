import React from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Header from './components/Header';

// Mock Pages for routing demonstration
const Page = ({ title, showPromo = false }: { title: string, showPromo?: boolean }) => (
  <div className="pt-24 pb-32 px-4 max-w-7xl mx-auto animate-fade-in">
    
    <Header 
      heading={title} 
      subHeading="This is a demo page for the route. Navigate through the menu to see the active states and responsive behavior."
      showPromo={showPromo}
    />
      
    <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
      {[1, 2, 3].map((i) => (
        <div key={i} className="h-40 bg-white dark:bg-[#111] border border-gray-100 dark:border-white/5 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow">
           <div className="h-2 w-24 bg-gray-100 dark:bg-white/10 rounded-full mb-4"></div>
           <div className="space-y-2">
             <div className="h-2 w-full bg-gray-50 dark:bg-white/5 rounded-full"></div>
             <div className="h-2 w-2/3 bg-gray-50 dark:bg-white/5 rounded-full"></div>
           </div>
        </div>
      ))}
    </div>

    <div className="mt-8 bg-white dark:bg-[#111] border border-gray-100 dark:border-white/5 rounded-3xl p-8 shadow-sm min-h-[400px] flex items-center justify-center text-gray-400 dark:text-gray-600 font-medium">
       Page Content Area
    </div>
  </div>
);

const AppLayout = () => {
  return (
    <div className="min-h-screen bg-[#FAFAFA] dark:bg-[#050505] selection:bg-indigo-500/30">
      <Navbar />
      <Routes>
        <Route path="/" element={<Page title="Dashboard" showPromo={true} />} />
        <Route path="/dashboard" element={<Page title="Dashboard" showPromo={true} />} />
        <Route path="/jobs" element={<Page title="Jobs Explorer" />} />
        <Route path="/applications" element={<Page title="My Applications" />} />
        <Route path="/chat" element={<Page title="Messages" />} />
        <Route path="/profile" element={<Page title="User Profile" showPromo={true} />} />
        <Route path="/saved-jobs" element={<Page title="Saved Jobs" />} />
        <Route path="/settings" element={<Page title="Settings" />} />
      </Routes>
    </div>
  );
};

export default function App() {
  return (
    <HashRouter>
      <AppLayout />
    </HashRouter>
  );
}
