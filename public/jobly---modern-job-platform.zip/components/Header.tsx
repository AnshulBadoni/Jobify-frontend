import React from "react";
import { CreditCard, TrendingUp, BadgeCheck, Star, ArrowRight, Calendar } from "lucide-react";

interface HeaderProps {
    heading: string;
    subHeading: string;
    showPromo?: boolean;
}

const Header = ({ heading, subHeading, showPromo = false }: HeaderProps) => {
    // Compact date format
    const currentDate = new Date().toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric"
    });

    return (
        <header className="relative bg-white dark:bg-[#09090b] border border-gray-200 dark:border-white/5 rounded-2xl p-5 shadow-sm transition-all duration-300">
            <div className={`flex flex-col lg:flex-row gap-6 ${showPromo ? 'items-start lg:items-center justify-between' : 'items-start'}`}>
                
                {/* Left Content */}
                <div className="flex-1 space-y-2 relative z-10">
                    
                    {/* Header Row with Title + Tags */}
                    <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-3 flex-wrap">
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">
                                {heading}
                            </h1>
                            
                            {/* Professional Tags */}
                            <div className="flex items-center gap-2">
                                <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-500/10 border border-blue-100 dark:border-blue-500/20 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-wide">
                                    <BadgeCheck size={12} strokeWidth={2.5} />
                                    Verified
                                </div>
                                <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-500/10 border border-amber-100 dark:border-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-bold uppercase tracking-wide">
                                    <Star size={12} strokeWidth={2.5} fill="currentColor" />
                                    Pro User
                                </div>
                            </div>
                        </div>
                        
                        <p className="text-sm text-gray-500 dark:text-gray-400 font-medium max-w-xl leading-relaxed">
                            {subHeading}
                        </p>
                    </div>

                    {/* Metadata / Utility Row */}
                    <div className="flex items-center gap-4 pt-1">
                         <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 dark:text-gray-500">
                            <Calendar size={12} />
                            {currentDate}
                        </div>
                        <div className="h-3 w-px bg-gray-200 dark:bg-gray-800"></div>
                        <button className="flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                            <TrendingUp size={12} />
                            <span>Analytics</span>
                        </button>
                    </div>
                </div>

                {/* Right Promo Card - Smaller & Professional */}
                {showPromo && (
                    <div className="w-full lg:w-[260px] flex-shrink-0 z-10">
                        <div className="relative group/card cursor-pointer transition-all duration-300 hover:-translate-y-1">
                            {/* Card Body - Compact Matte Black */}
                            <div className="relative bg-[#1a1a1a] dark:bg-black rounded-xl overflow-hidden shadow-lg border border-gray-800 dark:border-white/10 h-[140px]">
                                {/* Subtle Texture/Icon background */}
                                <div className="absolute -right-4 -top-4 text-white/5 transform rotate-12">
                                   <CreditCard size={80} />
                                </div>
                                
                                <div className="relative p-4 z-20 flex flex-col justify-between h-full">
                                    <div>
                                        <div className="flex justify-between items-start mb-2">
                                             <h3 className="text-xs font-bold text-white uppercase tracking-wider">Business Pro</h3>
                                             <span className="px-1.5 py-0.5 rounded bg-white text-[9px] font-bold text-black shadow-sm">PRO</span>
                                        </div>
                                        <div className="flex items-center gap-2 opacity-80">
                                            <div className="w-6 h-4 rounded bg-[#d4af37] opacity-90 relative overflow-hidden">
                                                <div className="absolute inset-0 border-t border-b border-black/10 my-1"></div>
                                                <div className="absolute inset-0 border-l border-r border-black/10 mx-1.5"></div>
                                            </div>
                                            <span className="text-white/60 text-[10px] font-mono tracking-widest">•••• 4298</span>
                                        </div>
                                    </div>

                                    <div className="flex justify-between items-end border-t border-white/10 pt-2.5">
                                        <div>
                                            <p className="text-[8px] text-gray-500 uppercase tracking-wider mb-0.5">Special Offer</p>
                                            <div className="flex items-baseline gap-1">
                                                <p className="text-sm font-bold text-white">$24</p>
                                                <p className="text-[10px] text-gray-500 line-through decoration-gray-500/50">$49</p>
                                            </div>
                                        </div>
                                        <button className="pl-3 pr-2 py-1 bg-white text-black rounded text-[10px] font-bold hover:bg-gray-200 transition-colors flex items-center gap-1 shadow-sm">
                                            Claim <ArrowRight size={10} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;