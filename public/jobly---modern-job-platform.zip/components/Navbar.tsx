import React, { useState, useEffect, useRef } from "react";
import {
  Bell,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Briefcase,
  Search,
  ChevronDown,
  HelpCircle,
  User,
  Zap,
  Settings,
  X,
  Clock,
  TrendingUp,
  Code,
  Palette,
  Megaphone,
  Globe,
  ArrowUp,
  ArrowDown,
  CornerDownLeft,
  Building2,
  Users,
  MapPin,
  CheckCircle2,
  Command
} from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Logo from "./Logo";

// --- Utility Hooks ---
function useClickOutside(ref: React.RefObject<HTMLElement>, handler: () => void) {
  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent) => {
      if (!ref.current || ref.current.contains(event.target as Node)) {
        return;
      }
      handler();
    };
    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);
    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, handler]);
}

export default function Navbar() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [isDesktopSearchOpen, setIsDesktopSearchOpen] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useClickOutside(dropdownRef, () => setIsDropdownOpen(false));

  // Handle Cmd+K for Desktop Search
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsDesktopSearchOpen((open) => !open);
      }
      if (e.key === "Escape") {
        setIsDesktopSearchOpen(false);
        setIsMobileSearchOpen(false);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const isActiveLink = (path: string) => location.pathname === path || (path !== "/" && location.pathname.startsWith(path + "/"));

  // Desktop Navigation Items (Job Platform Context)
  const desktopLinks = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Jobs", href: "/jobs", icon: Briefcase },
    { name: "Messages", href: "/chat", icon: MessageSquare },
    { name: "Activity", href: "/activity", icon: Zap },
  ];

  // Mobile Navigation Items
  const mobileNavItems = [
    { name: "Home", href: "/dashboard", icon: LayoutDashboard },
    { name: "Jobs", href: "/jobs", icon: Briefcase },
    { name: "Search", isAction: true, icon: Search },
    { name: "Chat", href: "/chat", icon: MessageSquare },
    { name: "Me", href: "/profile", icon: User },
  ];

  const handleLogout = () => {
    navigate("/signin");
  };

  return (
    <>
      {/* 
        ========================================
        DESKTOP NAVBAR
        ========================================
      */}
      <header className="hidden lg:block sticky top-0 z-50 bg-white/80 dark:bg-[#050505]/80 backdrop-blur-xl border-b border-gray-200/50 dark:border-white/5 transition-colors duration-300">
        <div className="max-w-[1600px] mx-auto px-6 h-18 flex items-center gap-8 py-3">
          
          {/* Left: Logo & Navigation */}
          <div className="flex items-center gap-10 flex-shrink-0">
            <Logo />
            
            {/* Nav Links */}
            <nav className="flex items-center gap-2 p-1 bg-gray-100/50 dark:bg-white/5 rounded-2xl border border-gray-200/50 dark:border-white/5">
              {desktopLinks.map((link) => {
                const active = isActiveLink(link.href);
                return (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`relative px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${
                      active 
                        ? "bg-gray-900 text-white dark:bg-white dark:text-black shadow-lg shadow-gray-900/10 dark:shadow-white/10 scale-100" 
                        : "text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200/50 dark:hover:bg-white/5"
                    }`}
                  >
                     {active && (
                       <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 dark:bg-indigo-500 animate-pulse"></span>
                     )}
                    {link.name}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Center: Search Trigger */}
          <div className="flex-1 max-w-lg relative ml-auto mr-auto">
             <div 
                onClick={() => setIsDesktopSearchOpen(true)}
                className="relative group cursor-pointer transition-transform duration-200 active:scale-[0.99]"
             >
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Search size={18} className="text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors" />
                </div>
                <div className="block w-full pl-11 pr-14 py-2.5 border border-gray-200 dark:border-white/10 rounded-2xl bg-gray-50/50 dark:bg-white/5 text-gray-500 dark:text-gray-400 text-sm font-medium hover:bg-white dark:hover:bg-white/10 hover:shadow-lg hover:shadow-gray-200/50 dark:hover:shadow-none hover:border-gray-300 dark:hover:border-white/20 transition-all">
                    Search jobs, companies...
                </div>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <kbd className="hidden sm:inline-flex items-center gap-0.5 h-6 px-2 rounded-lg bg-white dark:bg-black border border-gray-200 dark:border-white/10 font-sans text-[11px] font-semibold text-gray-400 shadow-sm">
                    <Command size={10} /> K
                  </kbd>
                </div>
             </div>
          </div>

          {/* Right: Actions & Profile */}
          <div className="flex items-center gap-3 flex-shrink-0">
            
            <button className="relative p-2.5 rounded-xl text-gray-500 hover:text-indigo-600 dark:text-gray-400 dark:hover:text-white hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-all group">
              <Bell size={20} strokeWidth={2} className="group-hover:scale-110 transition-transform" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white dark:ring-black animate-pulse" />
            </button>

            <button className="relative p-2.5 rounded-xl text-gray-500 hover:text-indigo-600 dark:text-gray-400 dark:hover:text-white hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-all group">
              <HelpCircle size={20} strokeWidth={2} className="group-hover:scale-110 transition-transform" />
            </button>

            {/* User Profile */}
            <div ref={dropdownRef} className="relative ml-2">
              <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className={`flex items-center gap-3 pl-1.5 pr-3 py-1.5 rounded-full border transition-all duration-200 ${
                  isDropdownOpen 
                    ? "bg-gray-50 dark:bg-white/10 border-indigo-200 dark:border-indigo-500/30 ring-2 ring-indigo-500/10" 
                    : "bg-white dark:bg-white/5 border-gray-200 dark:border-white/10 hover:border-indigo-200 dark:hover:border-white/20"
                }`}
              >
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  alt="James H" 
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-white dark:ring-[#111]"
                />
                <div className="hidden xl:block text-left mr-1">
                    <p className="text-sm font-bold text-gray-900 dark:text-white leading-none">James H.</p>
                </div>
                <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${isDropdownOpen ? "rotate-180 text-indigo-500" : ""}`} />
              </button>

              {/* Enhanced Dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 top-full mt-3 w-64 bg-white dark:bg-[#111] rounded-3xl shadow-2xl shadow-gray-200/50 dark:shadow-black/50 border border-gray-100 dark:border-white/10 py-2 z-50 animate-enter-menu origin-top-right overflow-hidden">
                  <div className="px-5 py-4 bg-gray-50/50 dark:bg-white/5 border-b border-gray-100 dark:border-white/5">
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Signed in as</p>
                    <p className="text-sm font-semibold truncate text-gray-900 dark:text-white">james@example.com</p>
                  </div>
                  <div className="p-2 space-y-0.5">
                    <Link to="/profile/1" className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-colors group">
                        <div className="p-1.5 rounded-lg bg-gray-100 dark:bg-white/10 text-gray-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                            <User size={16} />
                        </div>
                        My Profile
                    </Link>
                    <Link to="/settings" className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-colors group">
                         <div className="p-1.5 rounded-lg bg-gray-100 dark:bg-white/10 text-gray-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                            <Settings size={16} />
                        </div>
                        Settings
                    </Link>
                  </div>
                  <div className="border-t border-gray-100 dark:border-white/5 my-1 mx-2"></div>
                  <div className="p-2">
                    <button 
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-2xl transition-colors group"
                    >
                        <div className="p-1.5 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-500 group-hover:text-red-600 transition-colors">
                            <LogOut size={16} />
                        </div>
                        Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* 
        ========================================
        DESKTOP FULL SCREEN SEARCH OVERLAY
        ========================================
      */}
      {isDesktopSearchOpen && (
        <div className="hidden lg:flex fixed inset-0 z-[100] bg-gray-900/20 dark:bg-black/60 backdrop-blur-md items-start justify-center pt-[10vh]">
          <div className="absolute inset-0" onClick={() => setIsDesktopSearchOpen(false)} />
          
          <div className="w-full max-w-4xl bg-white dark:bg-[#0A0A0A] rounded-3xl shadow-2xl ring-1 ring-black/5 dark:ring-white/10 overflow-hidden animate-scale-in relative z-10 flex flex-col max-h-[80vh]">
            
            {/* Search Header */}
            <div className="flex-shrink-0 border-b border-gray-100 dark:border-white/5 p-5 bg-white dark:bg-[#0A0A0A]">
                <div className="flex items-center gap-4">
                    <Search className="text-gray-400 w-6 h-6" strokeWidth={2.5} />
                    <input 
                      autoFocus
                      placeholder="Search for jobs, companies, or candidates..." 
                      className="flex-1 bg-transparent text-xl font-medium text-gray-900 dark:text-white placeholder-gray-400 border-none outline-none"
                    />
                    <button 
                        onClick={() => setIsDesktopSearchOpen(false)}
                        className="p-2 rounded-xl bg-gray-100 dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 text-gray-500 transition-colors"
                    >
                        <span className="sr-only">Close</span>
                        <kbd className="text-xs font-semibold font-sans">ESC</kbd>
                    </button>
                </div>
            </div>

            {/* Quick Filters */}
            <div className="flex-shrink-0 px-5 py-3 border-b border-gray-100 dark:border-white/5 flex gap-3 bg-gray-50/50 dark:bg-[#111]">
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white dark:bg-white/10 border border-gray-200 dark:border-white/5 shadow-sm text-xs font-bold text-gray-900 dark:text-white">
                    All
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-white/5 border border-transparent text-xs font-medium text-gray-500 dark:text-gray-400 transition-all">
                    <Briefcase size={14} className="text-gray-400" /> Jobs
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-white/5 border border-transparent text-xs font-medium text-gray-500 dark:text-gray-400 transition-all">
                    <Building2 size={14} className="text-gray-400" /> Companies
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-white/5 border border-transparent text-xs font-medium text-gray-500 dark:text-gray-400 transition-all">
                    <Users size={14} className="text-gray-400" /> Candidates
                </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-3 scroll-smooth bg-gray-50/30 dark:bg-black/20">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-2">
                    {/* Recent Jobs */}
                    <div className="space-y-3">
                        <div className="flex items-center justify-between px-2">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Top Jobs</h3>
                        </div>
                        <div className="space-y-2">
                            {[
                                { title: "Senior Frontend Engineer", company: "Stripe", tags: ["Remote", "$180k+"], logo: "S" },
                                { title: "Product Designer", company: "Linear", tags: ["Hybrid", "$140k+"], logo: "L" },
                                { title: "Engineering Manager", company: "Vercel", tags: ["Remote", "$220k+"], logo: "V" }
                            ].map((job, i) => (
                                <div key={i} className="group flex items-center gap-4 p-3 rounded-2xl bg-white dark:bg-[#111] border border-gray-100 dark:border-white/5 hover:border-indigo-500/30 hover:shadow-lg hover:shadow-indigo-500/5 cursor-pointer transition-all">
                                    <div className="w-10 h-10 rounded-xl bg-gray-900 dark:bg-white text-white dark:text-black flex items-center justify-center font-bold text-lg">
                                        {job.logo}
                                    </div>
                                    <div className="flex-1">
                                        <h4 className="text-sm font-bold text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{job.title}</h4>
                                        <p className="text-xs text-gray-500">{job.company}</p>
                                    </div>
                                    <div className="flex gap-1">
                                        {job.tags.map(t => (
                                            <span key={t} className="px-2 py-1 rounded-md bg-gray-100 dark:bg-white/10 text-[10px] font-semibold text-gray-600 dark:text-gray-300">{t}</span>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Candidates */}
                    <div className="space-y-3">
                        <div className="flex items-center justify-between px-2">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">People</h3>
                        </div>
                         <div className="space-y-2">
                            {[
                                { name: "Sarah Connor", role: "Product Manager", status: "Open to work" },
                                { name: "John Smith", role: "Backend Dev", status: "Hired" },
                            ].map((person, i) => (
                                <div key={i} className="flex items-center gap-3 p-3 rounded-2xl bg-white dark:bg-[#111] border border-gray-100 dark:border-white/5 hover:bg-gray-50 dark:hover:bg-white/5 cursor-pointer transition-all">
                                    <img src={`https://i.pravatar.cc/150?u=${i+10}`} className="w-10 h-10 rounded-full object-cover" alt="" />
                                    <div>
                                        <h4 className="text-sm font-bold text-gray-900 dark:text-white">{person.name}</h4>
                                        <p className="text-xs text-gray-500">{person.role} • <span className="text-emerald-500">{person.status}</span></p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-100 dark:border-white/5 bg-gray-50 dark:bg-[#111] flex items-center justify-between text-xs text-gray-400">
                <div className="flex gap-4">
                    <span className="flex items-center gap-1"><ArrowUp size={12} /> <ArrowDown size={12} /> to navigate</span>
                    <span className="flex items-center gap-1"><CornerDownLeft size={12} /> to select</span>
                </div>
                <div>Jobly Search 2.0</div>
            </div>
          </div>
        </div>
      )}

      {/* 
        ========================================
        MOBILE NAVBAR (PREMIUM DARK DOCK)
        ========================================
      */}
      <nav className="lg:hidden fixed bottom-6 left-6 right-6 z-50">
        <div className="bg-[#111111]/95 backdrop-blur-2xl rounded-[32px] h-[72px] px-2 shadow-[0_8px_32px_rgba(0,0,0,0.4)] border border-white/10 flex items-center justify-between relative overflow-hidden ring-1 ring-white/5">
           
           {mobileNavItems.map((item, idx) => {
             // Search Action
             if (item.isAction) {
               return (
                 <div key={idx} className="flex-1 flex justify-center items-center">
                    <button 
                        onClick={() => setIsMobileSearchOpen(true)}
                        className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center shadow-[0_4px_20px_rgba(255,255,255,0.15)] hover:scale-105 active:scale-95 transition-all duration-300 group"
                    >
                        <Search size={26} strokeWidth={2.5} className="group-hover:rotate-90 transition-transform duration-500" />
                    </button>
                 </div>
               );
             }

             // Links
             const active = isActiveLink(item.href || '');
             return (
               <Link 
                 key={idx}
                 to={item.href || '#'}
                 className="flex-1 h-full flex flex-col items-center justify-center gap-1 relative group"
               >
                  <div className={`relative p-2 rounded-xl transition-all duration-300`}>
                    <item.icon 
                        size={24} 
                        strokeWidth={active ? 2.5 : 2} 
                        className={`transition-colors duration-300 ${active ? 'text-white' : 'text-gray-500 group-hover:text-gray-300'}`} 
                    />
                    {active && <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-white shadow-[0_0_8px_white] animate-in fade-in zoom-in"></span>}
                  </div>
               </Link>
             );
           })}
        </div>
      </nav>

      {/* Mobile Search Overlay */}
      {isMobileSearchOpen && (
        <div className="fixed inset-0 z-[60] bg-[#F8F9FA] dark:bg-black animate-fade-in flex flex-col lg:hidden font-sans">
           <div className="px-5 pt-6 pb-4 bg-white dark:bg-[#0A0A0A] shadow-sm z-10">
              <div className="flex items-center gap-4">
                 <div className="relative flex-1">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-900 dark:text-white" size={20} strokeWidth={2.5} />
                    <input 
                      autoFocus
                      type="text" 
                      placeholder="Search..." 
                      className="w-full pl-12 pr-4 py-4 bg-gray-100 dark:bg-[#1C1C1E] rounded-3xl border-none focus:ring-0 text-lg font-medium dark:text-white placeholder-gray-400"
                    />
                 </div>
                 <button 
                   onClick={() => setIsMobileSearchOpen(false)} 
                   className="w-10 h-10 flex items-center justify-center bg-gray-200 dark:bg-white/10 rounded-full text-gray-900 dark:text-white"
                 >
                   <X size={20} strokeWidth={2.5} />
                 </button>
              </div>
           </div>

           <div className="flex-1 overflow-y-auto px-5 py-6 space-y-8">
              <div className="space-y-4">
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">Recent</h3>
                  <div className="flex flex-wrap gap-2">
                       {['Product Design', 'Senior React', 'San Francisco'].map((item, i) => (
                          <button key={i} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-[#1C1C1E] rounded-full border border-gray-100 dark:border-white/5 shadow-sm active:scale-95 transition-transform">
                              <Clock size={14} className="text-gray-400" />
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{item}</span>
                          </button>
                       ))}
                  </div>
              </div>

              <div className="space-y-4">
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">Suggestions</h3>
                  <div className="grid grid-cols-2 gap-3">
                      {[
                          { label: 'Engineering', icon: Code, color: 'text-blue-500' },
                          { label: 'Design', icon: Palette, color: 'text-purple-500' },
                          { label: 'Marketing', icon: Megaphone, color: 'text-pink-500' },
                          { label: 'Finance', icon: TrendingUp, color: 'text-emerald-500' },
                      ].map((cat) => (
                          <div key={cat.label} className="p-4 bg-white dark:bg-[#1C1C1E] rounded-2xl flex flex-col gap-3 shadow-sm active:scale-95 transition-transform">
                              <cat.icon className={cat.color} size={24} />
                              <span className="font-bold text-sm text-gray-900 dark:text-white">{cat.label}</span>
                          </div>
                      ))}
                  </div>
              </div>
           </div>
        </div>
      )}

      <div className="h-28 lg:hidden" />
    </>
  );
}